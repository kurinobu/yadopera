/**
 * Axios設定
 * リクエスト/レスポンスインターセプターでJWTトークン追加とエラーハンドリング
 */

import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from 'axios'
import { useAuthStore } from '@/stores/auth'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

// Axiosインスタンス作成
const apiClient: AxiosInstance = axios.create({
  baseURL: `${API_BASE_URL}/api/v1`,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// リクエストインターセプター: JWTトークン追加
apiClient.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    const authStore = useAuthStore()
    const token = authStore.token

    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }

    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// レスポンスインターセプター: エラーハンドリング
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    return response
  },
  async (error) => {
    const authStore = useAuthStore()

    if (error.response) {
      const { status, data } = error.response

      // 401 Unauthorized: トークン無効または期限切れ
      if (status === 401) {
        authStore.logout()
        // TODO: ログイン画面にリダイレクト（Week 4で実装）
      }

      // エラーメッセージを返す
      const errorMessage = data?.detail || data?.message || 'エラーが発生しました'
      return Promise.reject(new Error(errorMessage))
    }

    // ネットワークエラーなど
    if (error.request) {
      return Promise.reject(new Error('ネットワークエラーが発生しました'))
    }

    return Promise.reject(error)
  }
)

export default apiClient

