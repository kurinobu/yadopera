/**
 * Pinia Store 設定
 */

import { createPinia } from 'pinia'

export const pinia = createPinia()

export default pinia

