# Render.com環境変数設定 最終確認

**OpenAI APIキー取得完了**: `sk-proj-...`（機密情報のため一部のみ表示）

---

## 設定する環境変数一覧（最終確認）

### Render.comダッシュボードで確認

1. Web Service（`yadopera-backend-staging`）を選択
2. 「**Environment**」タブを開く
3. 以下の環境変数が正しく設定されているか確認:

| Key | 値の確認ポイント |
|-----|----------------|
| `DATABASE_URL` | `postgresql+asyncpg://`で始まる（`postgresql://`ではない） |
| `REDIS_URL` | `redis://`で始まる |
| `OPENAI_API_KEY` | `sk-proj-`で始まる（実際のキーが設定されている） |
| `SECRET_KEY` | 64文字の16進数文字列 |
| `CORS_ORIGINS` | `https://yadopera-frontend-staging.onrender.com` |
| `ENVIRONMENT` | `staging` |
| `DEBUG` | `False` |
| `LOG_LEVEL` | `INFO` |

---

## 重要な確認事項

### OPENAI_API_KEY

- **現在の値**: `既存のOpenAI APIキー`（誤り）
- **正しい値**: `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`

**修正が必要**: `OPENAI_API_KEY`の値を実際のAPIキーに更新してください。

---

## 次のステップ

1. Render.comで`OPENAI_API_KEY`を修正
2. 環境変数の設定が完了したら、デプロイが自動的に再実行されます
3. デプロイ完了後、動作確認に進みます

---

## 注意事項

- OpenAI APIキーは機密情報です。他人に共有しないでください
- キーが漏洩した場合は、OpenAI Platformで無効化してください

