# やどぺら v0.2 要約定義書

**作成日**: 2025年11月19日  
**バージョン**: v0.21 (v0.2からのマイナーアップデート)  
**ベース**: v0.1要約定義書

---

## 変更履歴 v0.1 → v0.2

1. **RAG（検索拡張生成）統合**: pgvectorによるFAQ検索、AI従量コスト¥0.033/質問
2. **エスカレーションモード切り替え**: スタッフシフト連動（通常0.7 / 早期0.85）
3. **市場規模保守的修正**: 100-150施設（京都・大阪・東京）、月間質問数100件/施設
4. **FAQ初期件数明確化**: 20-30件テンプレート提供
5. **補助金活用戦略追加**: 最大70% OFF訴求
6. **認証・セッション詳細化**: パスワードリセット機能、Cookie保存、24時間有効期限
7. **UI/UX具体化**: ダークモード、PWA、スマホ最適化（375px-428px）
8. **将来フェーズ明確化**: Phase 4にPMS機能（部屋割、レンタルオプション、在庫管理）追加

---

## 1. 事業サマリー

### サービス概要
**やどぺら** = 「宿」 + 「ぺらぺら（流暢に話す）」

小規模宿泊施設向け外国人ゲスト対応自動化SaaS。QRコードをスマホで読み取るだけで、AIが24時間多言語自動応答。

### コアバリュー
**ゲスト側**
- アプリ不要、QRコードのみ
- 好きな言語で24時間質問可能
- 平均3秒以内レスポンス
- ダークモード対応

**宿側**
- 外国人ゲスト対応70%自動化（MVP目標、Phase 2で85%+）
- 月額¥3,980〜、初期費用¥0
- 導入ハードル低（QRコード掲示+基本設定）
- 20-30件FAQテンプレート提供

### 競合優位性
- やどびとネットワーク（実数200施設）
- RAG（検索拡張生成）で48%コスト削減
- 小規模施設特化（15-60床）、大手PMSが対応しきれないニッチ

---

## 2. ターゲット・課題

### ターゲット顧客
- **施設タイプ**: ゲストハウス・ホステル（15-60床）
- **外国人ゲスト比率**: 30%以上
- **スタッフ体制**: 1-3名
- **地域**: 京都・大阪・東京
- **市場規模**: 100-150施設（保守的推定）、やどびと実数200施設

### 顧客の課題
1. 英語対応スタッフ確保困難（採用コスト月給¥250,000+）
2. 夜間・無人時間帯の問い合わせ対応
3. 多言語資料作成・更新（翻訳¥50,000-100,000/言語）
4. 説明ミスによるトラブル

---

## 3. MVP機能仕様

### 3.1 ゲスト側機能

**アクセスURL**: `https://yadopera.com/f/{facility_id}?location={location}`

**画面フロー**
1. 言語選択画面（英語のみ、MVP）
2. ウェルカム画面（よくある質問TOP3、フリー入力、緊急連絡先）
3. AI対話インターフェース（チャット形式、PWA対応、ダークモード、固定フッター）

**セッション管理**
- SessionID: Cookie保存
- 有効期限: 無動作24時間で自動終了
- 複数デバイス: 同時アクセス許可（ゲスト行動考慮で必須）

**AI応答フロー（RAG統合型）**
```
質問受付
↓
埋め込みベクトル生成（OpenAI Embeddings）
↓
pgvectorで類似FAQ検索（コサイン類似度、Top 3取得）
↓
コンテキスト構築（約600トークン）
├ 関連FAQ Top 3: 300トークン
├ 施設基本情報: 150トークン
├ システムプロンプト: 100トークン
└ ゲスト質問: 50トークン
↓
GPT-4o miniで回答生成（最大200トークン出力）
↓
信頼度スコア計算（0.0-1.0）
├ FAQ類似度ボーナス（0.8以上: +0.3）
├ 回答長ペナルティ（20文字未満: -0.2）
└ 不確実性ワード検出（maybe等: -0.15）
↓
エスカレーション判定
↓
回答返却 or エスカレーション
```

**コスト効率**
- 1質問あたり: ¥0.033（RAG最適化後）
  - Input: 600トークン × $0.15/1M = $0.00009
  - Output: 200トークン × $0.60/1M = $0.00012
  - 合計: $0.00021 × ¥155 = ¥0.033
- 月100件/施設: ¥3.3/月
- 従来比48%削減

**エスカレーション機能**

*通常モード（デフォルト）*
- AI信頼度 < 0.7で自動エスカレーション
- 緊急キーワード検出（emergency, help, urgent, locked out, lost key, sick, injured, fire, police）
- 3往復以上未解決

*早期エスカレーションモード（スタッフ在席時）*
- AI信頼度 < 0.85で早めにエスカレーション
- ゲストコミュニケーションをチャンスと捉える施設向け
- 時間帯・曜日・言語・スタッフスキル別に管理画面で設定可能

**OpenAI API障害時フォールバック**

英語:
```
Sorry, the automatic support system is temporarily unavailable.
Please contact the staff directly for assistance.
```

日本語:
```
現在、自動案内システムが一時的に利用できません。
お手数ですがスタッフへ直接お問い合わせください。
```

宿側ログ:
```
AI API error: fallback_message_triggered
timestamp: xxxx-xx-xx xx:xx
guest_session_id: xxxx
error_type: OpenAI_API_timeout / rate_limit / server_error
```

**対応カテゴリ（MVP）**
- 基本情報: チェックイン/アウト時間、WiFiパスワード、支払い方法、門限
- 設備・サービス: キッチン、シャワー、洗濯機、タオル、ドライヤー、荷物預かり、自転車レンタル
- 館内ルール: ゴミ出し、騒音時間帯、喫煙所
- 周辺情報: コンビニ、駅、レストラン、ATM
- トラブル対応: 鍵紛失、WiFi不通、設備故障、体調不良

### 3.2 宿側機能（管理画面）

**認証システム**
- メールアドレス + パスワード認証（bcryptハッシュ化）
- JWT認証（python-jose、有効期限7日間）
- パスワードリセット機能（初期実装）
  - リセットトークン生成（有効期限1時間）
  - メール送信 → 新パスワード設定 → 完了通知

**ダッシュボード**
- 更新方式: REST API + ポーリング（手動更新）、WebSocket不要（MVP/PoC段階）
- リアルタイムチャット履歴（最新10件、ゲスト言語・質問・AI回答・信頼度表示）
- 週次サマリー（総質問数、カテゴリ別円グラフ、TOP5、未解決数、自動応答率）
- 未解決質問リスト（日時、内容、言語、「FAQ追加」ボタン）

**FAQ管理**
- **初期テンプレート20-30件提供**
  - 基本情報5件: チェックイン/アウト、WiFi、門限、朝食、支払い
  - 設備・サービス10件: ランドリー、キッチン、タオル、ドライヤー、喫煙所、荷物預かり、自転車、シャワー、共用スペース、プリンター
  - 周辺情報5件: コンビニ、レストラン、駅、ATM、観光アクセス
  - トラブル対応5件: 鍵紛失、WiFi不通、エアコン故障、お湯出ない、騒音
  - 拡張5件: チェックアウト延長、宅配便、タクシー、延泊、アレルギー

- FAQ登録・編集
  - 質問文（英語、200文字以内推奨）
  - 回答文（英語、200文字以内推奨）
  - カテゴリ選択（basic, facilities, location, trouble）
  - 優先度設定（1-5）
  - 埋め込みベクトル自動生成（pgvector、保存時自動実行）

- 宿情報設定
  - 基本: 名称、住所、電話、メール
  - WiFi: SSID、パスワード（暗号化保存）
  - チェックイン・アウト時間
  - 館内ルール（自由記述）
  - 周辺情報

**エスカレーションスケジュール管理**

設定項目:
```yaml
例1: 平日日中（英語対応スタッフ在席）
- 曜日: ["mon", "tue", "wed", "thu", "fri"]
  時間: "09:00-18:00"
  モード: "early"（早期エスカレーション）
  閾値: 0.85
  言語: ["en", "ja"]
  通知: ["email"]

例2: 夜間（緊急時のみ）
- 曜日: "all"
  時間: "18:00-09:00"
  モード: "normal"（通常）
  閾値: 0.7
  言語: ["en", "ja"]
  通知: ["email"]
```

**QRコード発行**
- 施設専用QRコード生成
- 設置場所別（entrance / room / kitchen / lounge / custom）
- PDF/PNG/SVG形式ダウンロード（A4印刷用）
- スキャン回数トラッキング

---

## 4. 技術スタック

### フロントエンド
- **Vue.js 3** (Composition API)
- **TypeScript 5.3+**
- **Tailwind CSS 3.4+**（シンプル・拡張性重視）
- **Vite 5.0+**（ビルドツール）
- **Pinia 2.1+**（状態管理）
- **Axios 1.6+**（HTTP通信）
- **Vite PWA Plugin 0.19+**（PWA対応）

### バックエンド
- **FastAPI 0.109+**（Python 3.11+）
- **SQLAlchemy 2.0+**（ORM、async対応）
- **Alembic 1.13+**（マイグレーション）
- **uvicorn 0.27+**（ASGIサーバー）
- **python-jose 3.3+**（JWT認証）
- **passlib 1.7+**（bcryptパスワードハッシュ化）
- **Redis 7.2+**（キャッシュ・セッション・Rate Limit）

**FastAPI選択理由**
1. 非同期処理がネイティブ（OpenAI API呼び出しに最適）
2. 型安全性（Pydantic統合で自動バリデーション）
3. 自動ドキュメント生成（Swagger UI標準搭載）
4. 高パフォーマンス（Flask比3-5倍高速）
5. モダンなエコシステム（SQLAlchemy 2.0 async、LangChain親和性）

### AI/ML
- **OpenAI API**: GPT-4o mini（gpt-4o-mini-2024-07-18）、text-embedding-3-small
- **LangChain 0.1+**（プロンプト管理）
- **pgvector 0.2+**（ベクトル検索、RAG）
- **tiktoken 0.5+**（トークン数計算）

### データベース・インフラ
- **PostgreSQL 15+**（pgvector拡張）
- **Redis Cloud**（キャッシュ・セッション）
- **Render.com**（Starter → Pro Plan）
- **Cloudflare**（CDN、DDoS保護、SSL/TLS）
- **AWS S3**（QRコード・画像保存）
- **GitHub Actions**（CI/CD、Phase 2）

---

## 5. データベース設計（概要）

### 主要テーブル

**facilities**（宿泊施設）
```sql
id SERIAL PRIMARY KEY
name VARCHAR(255)
slug VARCHAR(100) UNIQUE  -- URL用
email VARCHAR(255)
phone VARCHAR(50)
wifi_ssid VARCHAR(100)
wifi_password VARCHAR(100)  -- 暗号化保存
check_in_time TIME DEFAULT '15:00'
check_out_time TIME DEFAULT '11:00'
languages TEXT[] DEFAULT ARRAY['en']
timezone VARCHAR(50) DEFAULT 'Asia/Tokyo'
subscription_plan VARCHAR(50) DEFAULT 'small'
monthly_question_limit INTEGER DEFAULT 200
is_active BOOLEAN DEFAULT TRUE
created_at TIMESTAMP DEFAULT NOW()
updated_at TIMESTAMP DEFAULT NOW()
```

**users**（管理者ユーザー）
```sql
id SERIAL PRIMARY KEY
facility_id INTEGER REFERENCES facilities(id)
email VARCHAR(255) UNIQUE
password_hash VARCHAR(255)  -- bcrypt
role VARCHAR(50) DEFAULT 'staff'  -- 'owner', 'staff', 'admin'
full_name VARCHAR(255)
is_active BOOLEAN DEFAULT TRUE
last_login_at TIMESTAMP
password_reset_token VARCHAR(255)
password_reset_expires TIMESTAMP
created_at TIMESTAMP
updated_at TIMESTAMP
```

**faqs**（FAQ + pgvector）
```sql
-- pgvector拡張を有効化
CREATE EXTENSION IF NOT EXISTS vector;

id SERIAL PRIMARY KEY
facility_id INTEGER REFERENCES facilities(id)
category VARCHAR(100)  -- 'basic', 'facilities', 'location', 'trouble'
language VARCHAR(10)  -- 'en', 'ja', 'zh-TW', 'fr'
question TEXT
answer TEXT
embedding vector(1536)  -- OpenAI Embeddings
priority INTEGER DEFAULT 1
is_active BOOLEAN DEFAULT TRUE
created_by INTEGER REFERENCES users(id)
created_at TIMESTAMP
updated_at TIMESTAMP

-- IVFFlat: 高速近似最近傍探索
CREATE INDEX idx_faqs_embedding ON faqs 
USING ivfflat (embedding vector_cosine_ops);
```

**conversations**（会話）
```sql
id SERIAL PRIMARY KEY
facility_id INTEGER REFERENCES facilities(id)
session_id VARCHAR(100) UNIQUE  -- Cookie保存用
guest_language VARCHAR(10) DEFAULT 'en'
location VARCHAR(50)  -- 'entrance', 'room', 'kitchen', 'lounge'
user_agent TEXT
ip_address INET
started_at TIMESTAMP DEFAULT NOW()
last_activity_at TIMESTAMP DEFAULT NOW()  -- 24時間判定用
ended_at TIMESTAMP
is_escalated BOOLEAN DEFAULT FALSE
total_messages INTEGER DEFAULT 0
auto_resolved BOOLEAN DEFAULT FALSE
```

**messages**（メッセージ）
```sql
id SERIAL PRIMARY KEY
conversation_id INTEGER REFERENCES conversations(id)
role VARCHAR(20)  -- 'user', 'assistant', 'system'
content TEXT
ai_confidence DECIMAL(3,2)  -- 0.00-1.00
matched_faq_ids INTEGER[]  -- 使用したFAQ IDリスト
tokens_used INTEGER
response_time_ms INTEGER
created_at TIMESTAMP
```

**escalations**（エスカレーション）
```sql
id SERIAL PRIMARY KEY
facility_id INTEGER REFERENCES facilities(id)
conversation_id INTEGER REFERENCES conversations(id)
trigger_type VARCHAR(50)  -- 'low_confidence', 'keyword', 'multiple_turns', 'staff_mode'
ai_confidence DECIMAL(3,2)
escalation_mode VARCHAR(50)  -- 'normal', 'early'
notified_at TIMESTAMP
notification_channels TEXT[]  -- ['email', 'slack', 'line']
resolved_at TIMESTAMP
resolved_by INTEGER REFERENCES users(id)
resolution_notes TEXT
created_at TIMESTAMP
```

**escalation_schedules**（エスカレーションスケジュール）
```sql
id SERIAL PRIMARY KEY
facility_id INTEGER REFERENCES facilities(id)
day_of_week TEXT[]  -- ['mon', 'tue'] or ['all']
time_start TIME
time_end TIME
mode VARCHAR(50) DEFAULT 'normal'  -- 'normal', 'early'
languages TEXT[] DEFAULT ARRAY['en', 'ja']
threshold DECIMAL(3,2) DEFAULT 0.70
notify_channels TEXT[] DEFAULT ARRAY['email']
is_active BOOLEAN DEFAULT TRUE
created_at TIMESTAMP
updated_at TIMESTAMP
```

**qr_codes**（QRコード）
```sql
id SERIAL PRIMARY KEY
facility_id INTEGER REFERENCES facilities(id)
location VARCHAR(100)  -- 'reception', 'room', 'common_area'
url TEXT  -- https://yadopera.com/f/{facility_id}?location={location}
file_path VARCHAR(255)  -- S3保存先
scan_count INTEGER DEFAULT 0
last_scanned_at TIMESTAMP
created_at TIMESTAMP
updated_at TIMESTAMP
```

**データ保持ポリシー**: 3ヶ月経過した会話データを自動削除（GDPR対応、Celeryバッチ処理Phase 2）

---

## 6. API設計

### API バージョニング
**最初から実装**: `/api/v1/`

理由: 実装負荷ゼロ、将来的な後方互換性確保、破壊的変更時のスムーズな移行

### エンドポイント一覧

**Guest API**
- GET `/api/v1/facility/{slug}` 施設情報取得
- POST `/api/v1/chat` チャットメッセージ送信
- GET `/api/v1/chat/history/{session_id}` 会話履歴取得
- POST `/api/v1/feedback` フィードバック送信（Phase 2）

**Admin API**
- POST `/api/v1/auth/login` ログイン
- POST `/api/v1/auth/logout` ログアウト（JWT必須）
- POST `/api/v1/auth/password-reset` パスワードリセット要求
- POST `/api/v1/auth/password-reset/confirm` パスワードリセット確定
- GET `/api/v1/admin/dashboard` ダッシュボードデータ（JWT必須）
- GET/POST/PUT/DELETE `/api/v1/admin/faqs` FAQ管理（JWT必須）
- GET/PUT `/api/v1/admin/escalations` エスカレーション管理（JWT必須）
- POST `/api/v1/admin/qr-code` QRコード生成（JWT必須）
- GET/POST/PUT `/api/v1/admin/escalation-schedule` スケジュール管理（JWT必須）

---

## 7. 開発スケジュール

### Phase 0: 準備（1週間）
- アーキテクチャ設計書v0.2作成
- 開発環境構築（Docker, PostgreSQL, pgvector）
- GitHub リポジトリ作成
- OpenAI API キー取得（Embeddings API含む）
- Render アカウント準備

### Phase 1: MVP開発（4週間）

**Week 1: バックエンド基盤**
- FastAPI プロジェクト初期化
- PostgreSQL 接続（pgvector拡張有効化）
- JWT認証システム（パスワードリセット含む）
- facilities, users, faqs テーブル実装
- API バージョニング `/api/v1/` 実装

**Week 2: AI対話エンジン**
- OpenAI API 統合（GPT-4o mini, Embeddings）
- RAG実装（pgvectorで類似FAQ検索）
- プロンプトエンジニアリング
- 信頼度スコア計算ロジック
- エスカレーション判定ロジック
- conversations, messages, escalations テーブル実装
- フォールバック文言実装
- エラーログ記録機能

**Week 3: フロントエンド**
- Vue.js プロジェクト初期化（TypeScript）
- ゲスト側UI（QR読み取り後画面、PWA対応、ダークモード）
- Cookie-based セッション管理（24時間有効期限）
- チャットインターフェース（固定フッター）
- 管理画面（ダッシュボード、ポーリング実装）
- FAQ管理画面（埋め込みベクトル自動生成）
- エスカレーションスケジュール設定画面
- パスワードリセットフロー実装

**Week 4: 統合・テスト**
- エンドツーエンドテスト
- レスポンス速度最適化（キャッシュ、async/await）
- エラーハンドリング（OpenAI API障害時）
- QRコード生成機能（S3連携）
- Rate Limiting実装
- Render デプロイ
- 本番環境テスト

### Phase 2: PoC準備（2週間）
- やどびとユーザーへのメールDM作成・送信（100-150施設）
- オンライン説明会準備（Zoom、週1回×4週間）
- PoC施設選定（5-7施設、選定基準に基づく）
- 初期FAQ作成支援（20-30件テンプレート提供）
- 利用マニュアル作成（PDF、動画）
- KPIトラッキング設定
- 専用Slackチャンネル作成

### Phase 3: PoC実施（3ヶ月）
- 5-7施設同時スタート
- 週次ヒアリング（30分ミーティング×施設数）
- FAQ最適化（実データに基づく）
- バグ修正・機能改善（Agile開発）
- 成功事例の記録（写真、動画、コメント）
- 中間レポート作成・共有（1ヶ月後）
- 最終レポート作成（終了時）
- 有料転換率測定

### Phase 4: 本格展開準備（1ヶ月）
- PoC結果を反映した機能改善
- 決済機能実装（Stripe連携）
- 多言語対応（繁体中国語）
- Slack/LINE通知連携
- 分析レポート機能強化
- 料金プラン確定
- 利用規約・プライバシーポリシー整備

**合計期間**: 約5ヶ月

---

## 8. PoC計画

### 対象施設選定基準
| 条件 | 目標値 | 理由 |
|------|-------|------|
| 外国人ゲスト比率 | 30%以上 | 利用頻度を確保 |
| スタッフ体制 | 1-3名 | 課題が顕在化 |
| ベッド数 | 15-60床 | 規模別の検証 |
| やどびと利用実績 | 過去6ヶ月 | 信頼関係あり |
| 立地分散 | 京都2/大阪2/東京1 | 地域差の検証 |

### 施設タイプの分散
- ドミトリー中心: 2施設
- 個室中心: 2施設
- 混合タイプ: 1施設

### PoC提供内容
- 月額料金: **完全無料**（3ヶ月間）
- AI利用制限: なし（無制限）
- 初期設定サポート: FAQ登録支援、施設情報入力代行
- 専用Slackチャンネル: 質問・要望に即時対応
- 週次ミーティング: 30分オンライン（Zoom）
- 週次レポート: 自動送信（質問数、自動応答率、カテゴリ分布）
- 中間レポート: 1ヶ月後に詳細分析レポート
- 最終レポート: 終了時に成功事例まとめ

### 検証KPI

**定量指標**
| KPI | 目標値 | 測定方法 |
|-----|-------|----------|
| 総質問数 | 100件/月/施設 | conversations テーブル集計 |
| 自動応答率 | 70%以上 | (総質問数 - エスカレーション数) / 総質問数 |
| 平均レスポンス時間 | 3秒以内 | response_time_ms 平均値 |
| 夜間質問数 (22-8時) | 30件/月/施設 | 時間帯別集計 |
| エスカレーション率 | 30%以下 | エスカレーション数 / 総質問数 |

**定性指標（ヒアリング）**
- スタッフの体感負担度（5段階評価）: 開始前 vs 終了後
- 「これならいくらまで払えるか？」料金感度調査
- 次に欲しい機能TOP3
- NPS（Net Promoter Score）

### 成功基準
- PoC終了後の有料転換率: **60%以上**（5施設中3-4施設）
- NPS: **+30以上**
- クリティカルバグ: **0件**
- スタッフ負担度改善: 平均**2ポイント以上**向上

---

## 9. 収益モデル

### 価格設定（本導入後）
| プラン | 対象規模 | 月額料金 | 質問数上限 | 対応言語 | サポート |
|--------|----------|----------|-----------|----------|----------|
| Small | 〜25床 | ¥3,980 | 200件/月 | 英語のみ | メール |
| Standard | 26-50床 | ¥5,980 | 500件/月 | 英語+2言語 | メール+チャット |
| Premium | 51床以上 | ¥7,980 | 1,000件/月 | 全言語 | 優先サポート |

**共通機能**: 初期費用¥0、QRコード無制限生成、基本分析レポート、データ保持3ヶ月

### コスト構造（月額）

**固定費**
| 項目 | 金額 |
|------|------|
| Render Web Service | ¥9,000 |
| PostgreSQL | ¥6,000 |
| Redis | ¥3,000 |
| AWS S3 | ¥1,000 |
| ドメイン・SSL | ¥500 |
| **合計** | **¥19,500-25,000** |

**変動費（施設あたり）**
- OpenAI API: ¥3.3/月（100件/月想定、RAG最適化後）
  - 1質問: ¥0.033 × 100件 = ¥3.3

**運用費**
- 開発・保守: ¥120,000-150,000/月（Air人件費）
- カスタマーサポート: ¥30,000/月（Phase 2以降）

### 収益シミュレーション

**Year 1（基準シナリオ）**
- 平均ARPU: ¥5,000/月（Small 40% / Standard 50% / Premium 10%）
- 月間質問数: 100件/施設
- AI従量コスト: ¥3.3/施設/月
- チャーン率: 10%/年

Q1（M1-M3）: PoC期間
- 契約施設: 5施設、売上¥0（無料）、営業利益-¥145,000/月

Q2-Q4（M4-M12）: 成長期
- M12: 30施設、売上¥150,000/月
- 年間売上（後半6ヶ月平均）: ¥900,000
- 粗利（80%）: ¥720,000
- 営業利益: 約±¥0（損益分岐点達成）

**Year 2（成長シナリオ）**
- 目標: 60施設
- 月間売上（平均）: ¥300,000
- 年間売上: ¥3,600,000
- 粗利（80%）: ¥2,880,000
- 営業利益: ¥420,000-900,000

**損益分岐点**
- 月次固定費: ¥145,000（固定費¥25k + 運用費¥120k）
- BEP = ¥145,000 / (¥5,000 × 0.8) = 36.25施設
- 実質37施設で損益分岐、Year 1 Q4（12ヶ月目）で30施設想定のため、Year 2 Q1で黒字化

### 補助金活用戦略

**1. 小規模事業者持続化補助金**
- 補助率: 導入費用の2/3
- 上限額: ¥500,000（通常枠）
- 対象: ソフトウェア導入費、初期設定サポート
- 想定補助額: ¥200,000-300,000

**2. 中小企業省力化補助金（IT導入補助金）**
- 補助率: 1/2
- 上限額: ¥2,000,000
- 対象: 省力化ツール導入
- 想定補助額: 年間¥48,000の半額 = ¥24,000

**3. 自治体インバウンド推進事業**
- 補助率: 実証費用の全額〜2/3
- 連携自治体: 京都市、大阪市、東京都（観光課）
- 活用例: PoC期間中の実証実験費用

**顧客メリット**
- Year 1利用料: ¥3,980 × 12ヶ月 = ¥47,760
- 補助金適用後: 実質負担¥15,920〜
- 実質割引率: 最大67% OFF

**申請サポート**
- 申請書類テンプレート提供
- 申請代行サービス（Phase 2、¥30,000〜）
- 自治体との連携による推奨ツール認定取得

---

## 10. GTM戦略（やどびと活用）

### フェーズ1: PoC施設募集（1ヶ月）

**1. メールDM戦略**（100-150施設）

件名: 【やどびと特典】外国人ゲスト対応を自動化する新ツール、無料PoC募集

本文構成:
```
━━━━━━━━━━━━━━━━━━━━━
【やどびと】をご利用いただきありがとうございます

外国人ゲスト対応でこんなお悩みありませんか？
✓ 英語対応スタッフの確保が難しい
✓ 夜間の問い合わせ対応が大変
✓ 多言語資料の作成・更新が追いつかない

【やどぺら】が、これらの課題を解決します

・QRコード読み取りだけで、24時間多言語AI対応
・夜間の問い合わせを70%自動化
・月額¥3,980〜の低コスト
・初期費用ゼロ

【期間限定】無料PoC参加施設を5施設募集中
・3ヶ月間完全無料
・週次レポート自動送信
・専用サポートSlackチャンネル

デモ動画（1分）: https://yadopera.com/demo
応募フォーム: https://yadopera.com/poc-apply

やどびと運営チーム
━━━━━━━━━━━━━━━━━━━━━
```

**2. やどびと上でのプロモーション**
- バナー広告（トップページ、求人ページ）
- 特集記事「外国人ゲスト対応の課題と最新ソリューション」
- 求人掲載時のポップアップ案内
- やどびと公式SNSでの告知

**3. オンライン説明会**
- 頻度: 週1回×4週間（計4回）
- 時間: 毎週水曜日 18:00-18:30（30分）
- ツール: Zoom、定員20施設/回
- プログラム: 課題共有（10分）+ デモ（15分）+ Q&A（5分）
- 録画配信あり、参加者優先PoC案内

### フェーズ2: PoC実施（3ヶ月）
- 週次ヒアリング（30分）
- 専用Slackでの即時サポート
- 改善要望の即時反映
- 成功事例の記録（写真、動画、数値）

### フェーズ3: 成功事例の発信（PoC後）
- やどびと特集記事
- 導入施設インタビュー動画（3-5分×3本）
- 「問い合わせ70%削減」等の具体的数値訴求
- プレスリリース配信

### フェーズ4: 本格展開
- 紹介キャンペーン（紹介元: 初月無料、紹介先: 初月50% OFF）
- やどびと年間契約ユーザー特典
- 業界団体・自治体連携
- 商工会議所での事例発表

---

## 11. 将来拡張（Phase 2-4）

### Phase 2（PoC終了後 3-6ヶ月）
- **多言語追加**: 繁体中国語、フランス語
- **通知機能強化**: Slack/LINE連携、緊急度別設定
- **分析機能拡充**: カテゴリ統計、時間帯ヒートマップ、月次PDF
- **キャッシュ最適化**: Redis活用強化、頻出FAQキャッシュ

### Phase 3（6-12ヶ月）
- **多言語完全対応**: 簡体中国語、韓国語、自動言語判定
- **軽量PMS機能**: 宿泊者一覧、簡易部屋割（ドラッグ&ドロップ）、引き継ぎメモ
- **要望管理**: トラブル報告、ステータス管理（未対応・対応中・完了）
- **高度分析**: 満足度スコアリング、ベンチマーク、予測分析

### Phase 4（12-24ヶ月）
- **簡易PMS完全版**: 複数施設管理、予約システム連携（Airbnb、Booking.com）
- **レンタル自転車等オプション管理**: 在庫管理、貸出・返却記録、予約受付、決済統合（Stripe）
- **サプライ品在庫管理**: タオル、アメニティ、清掃用品の在庫追跡、発注アラート、ベンダー管理
- **アップセル機能**: 延泊・アーリーチェックイン提案、ローカル体験・ツアー紹介（アフィリエイト10-15%）
- **音声対応**: Whisper API（音声入力）、TTS（音声出力）
- **画像認識**: 設備トラブル診断、翻訳機能

---

## 12. リスクと対策

### 技術リスク
| リスク | 影響度 | 対策 |
|--------|--------|------|
| OpenAI API障害 | 高 | フォールバック文言、キャッシュ、複数APIキーローテーション |
| AI回答精度不足 | 高 | RAG最適化、継続的プロンプト改善、エスカレーション |
| レスポンス遅延 | 中 | async/await、CDN、ストリーミング表示 |
| pgvector性能劣化 | 中 | IVFFlatインデックス最適化、定期VACUUM |
| データ漏洩 | 高 | SSL/TLS、データ暗号化、最小権限原則、定期監査 |

### ビジネスリスク
| リスク | 影響度 | 対策 |
|--------|--------|------|
| PoCで効果が出ない | 高 | 施設選定厳密化、早期改善サイクル |
| チャーン率高 | 中 | オンボーディング強化、週次レポート、CS体制 |
| 競合参入 | 中 | やどびとネットワーク先行優位、PMS連携差別化 |
| 市場規模過大評価 | 高 | アンケート実施、保守的推定、ピボット準備 |
| 一人開発の限界 | 高 | セルフサービス化、自動化、Phase 3外注検討 |

### 法的・コンプライアンスリスク
| リスク | 影響度 | 対策 |
|--------|--------|------|
| 個人情報漏洩 | 高 | プライバシーポリシー整備、GDPR準拠、3ヶ月自動削除 |
| AI誤答による損害 | 中 | 利用規約免責事項、緊急時人間対応誘導、PL保険検討 |
| 宿泊業法抵触 | 低 | 本人確認・台帳機能は将来PMS連携で対応 |

---

## 13. 開発コスト概算

### 自己開発（Air単独）
| 項目 | 工数 | 備考 |
|------|------|------|
| MVP開発 | 160時間 | 4週間 × 40h/週 |
| PoC対応 | 40時間 | 週次MTG、改善対応 |
| Phase 2開発 | 80時間 | 多言語・通知機能 |
| **合計** | **280時間** | 約2ヶ月フルタイム相当 |

### 外注の場合（参考）
| 項目 | 金額 |
|------|------|
| バックエンド開発 | ¥800,000 |
| フロントエンド開発 | ¥600,000 |
| デザイン | ¥200,000 |
| **合計** | **¥1,600,000** |

### 運用コスト（月額）
| 項目 | 金額 |
|------|------|
| Render | ¥9,000 |
| PostgreSQL | ¥6,000 |
| Redis | ¥3,000 |
| OpenAI API | ¥5,000-20,000 |
| AWS S3 | ¥1,000 |
| ドメイン・SSL | ¥500 |
| **合計** | **¥24,500-39,500** |

**損益分岐点**: 5-7施設（¥30,000/月売上）

---

## 14. 成功指標（KPI）

### 短期（PoC終了時）
- PoC参加施設: 5-7施設
- 自動応答率: 70%以上
- 継続利用意向: 60%以上（有料転換）
- 成功事例: 2件以上
- NPS: +30以上

### 中期（1年後）
- 有料契約施設: 30施設
- 月間売上: ¥150,000
- チャーン率: 15%以下
- 平均レスポンス時間: 3秒以内維持
- 自動応答率: 85%達成

### 長期（2年後）
- 契約施設: 60施設
- 月間売上: ¥300,000
- チャーン率: 10%以下
- アップセル機能利用率: 30%
- 自治体連携: 3地域

---

## 15. 次のアクション

### 即時（1週間以内）
- [ ] アーキテクチャ設計書v0.2作成
- [ ] 開発環境構築（Docker, PostgreSQL, pgvector）
- [ ] GitHub リポジトリ作成
- [ ] OpenAI API キー取得（Embeddings API含む）
- [ ] Render アカウント準備

### 開発準備（2週間以内）
- [ ] データベース設計詳細化（pgvector含む）
- [ ] API仕様書作成（OpenAPI 3.0形式）
- [ ] UI/UXワイヤーフレーム作成（Figma）
- [ ] 初期FAQリスト作成（20-30件サンプル）
- [ ] やどびとアンケート設計・実施

### MVP開発開始
- [ ] Week 1: バックエンド基盤構築（FastAPI + pgvector + JWT認証）
- [ ] Week 2: AI対話エンジン実装（RAG統合 + エスカレーション）
- [ ] Week 3: フロントエンド実装（Vue.js + PWA + ダークモード）
- [ ] Week 4: 統合テスト・デプロイ

---

## 付録

### A. サービス名の由来
**やどぺら** = 「宿」 + 「ぺらぺら（流暢に話す）」
- 外国人ゲストとぺらぺら話せる宿になる
- 覚えやすく、親しみやすい日本語
- 「やどびと」との語感の親和性

### B. 初期FAQテンプレート30件

**基本情報（5件）**
1. チェックイン/チェックアウト時間は？
2. WiFiパスワードは？
3. 門限はありますか？
4. 朝食は提供されますか？
5. 支払い方法は？

**設備・サービス（10件）**
6. コインランドリーはありますか？
7. キッチンは使えますか？
8. タオルはありますか？
9. ドライヤーはありますか？
10. 喫煙所はありますか？
11. 荷物預かりはできますか？
12. 自転車レンタルはありますか？
13. シャワーは24時間使えますか？
14. 共用スペースの利用時間は？
15. プリンターは使えますか？

**周辺情報（5件）**
16. 最寄りのコンビニはどこですか？
17. おすすめのレストランは？
18. 駅までの行き方は？
19. 近くのATMはどこですか？
20. 観光地へのアクセスは？

**トラブル対応（5件）**
21. 鍵を部屋に忘れました
22. WiFiに繋がりません
23. エアコンが動きません
24. お湯が出ません
25. 騒音が気になります

**拡張（5件）**
26. チェックアウト延長は可能ですか？
27. 宅配便は受け取れますか？
28. タクシーを呼んでもらえますか？
29. 延泊したいのですが
30. アレルギー対応はできますか？

### C. 参考URL
- やどびと: https://yadobito.com
- Render: https://render.com
- OpenAI API: https://platform.openai.com
- FastAPI: https://fastapi.tiangolo.com
- pgvector: https://github.com/pgvector/pgvector
- Vue.js: https://vuejs.org
- Tailwind CSS: https://tailwindcss.com

### D. 問い合わせ
- 開発者: Air
- ブログ: https://air-edison.com
- Twitter: @kbqjp
- Email: [作成時に追記]

---

**Document Version**: v0.21  
**Based on**: v0.1 要約定義書  
**Author**: Air  
**Last Updated**: 2025-11-19  
**Status**: 開発準備完了

---

## 変更履歴 v0.2 → v0.21

1. **JWT認証ライブラリ修正**: Flask-JWT-Extended → python-jose（FastAPI使用のため）