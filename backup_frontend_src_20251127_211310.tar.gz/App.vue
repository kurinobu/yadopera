<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900">
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-4xl font-bold text-center text-gray-900 dark:text-white mb-4">
        やどぺら
      </h1>
      <p class="text-center text-gray-600 dark:text-gray-400">
        開発環境構築中
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
// App component
</script>

<style scoped>
/* Component styles */
</style>


